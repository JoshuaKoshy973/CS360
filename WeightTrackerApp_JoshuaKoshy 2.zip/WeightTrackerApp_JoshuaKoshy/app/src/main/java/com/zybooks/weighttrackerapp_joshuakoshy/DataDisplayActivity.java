package com.zybooks.weighttrackerapp_joshuakoshy;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.*;

public class DataDisplayActivity extends AppCompatActivity {

    static class WeightEntry {
        int id;
        String date;
        double weight;
        String note;
        WeightEntry(int id, String date, double weight, String note) {
            this.id = id; this.date = date; this.weight = weight; this.note = note;
        }
    }

    private EditText etDate, etWeight, etNote;
    private TextView tvEmpty;
    private final ArrayList<WeightEntry> data = new ArrayList<>();
    private WeightAdapter adapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dbHelper = new DatabaseHelper(this);
        etDate = findViewById(R.id.etDate);
        etWeight = findViewById(R.id.etWeight);
        etNote = findViewById(R.id.etNote);
        tvEmpty = findViewById(R.id.tvEmpty);

        RecyclerView recycler = findViewById(R.id.recycler);
        recycler.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new WeightAdapter(data, new RowActions() {
            @Override public void onDelete(int pos) {
                dbHelper.deleteWeight(data.get(pos).id);
                loadWeights();
            }
            @Override public void onEdit(int pos) { showEditDialog(pos); }
        });
        recycler.setAdapter(adapter);

        loadWeights();

        findViewById(R.id.btnAdd).setOnClickListener(v -> {
            String d = etDate.getText().toString().trim();
            String w = etWeight.getText().toString().trim();
            String n = etNote.getText().toString().trim();
            if (TextUtils.isEmpty(d) || TextUtils.isEmpty(w)) {
                Toast.makeText(this, "Enter date & weight", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                double val = Double.parseDouble(w);
                dbHelper.addWeight(d, val, n);
                loadWeights();
                clearInputs();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Weight must be a number", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.btnReset).setOnClickListener(v -> clearInputs());
    }

    private void loadWeights() {
        data.clear();
        Cursor cursor = dbHelper.getAllWeights();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
            String note = cursor.getString(cursor.getColumnIndexOrThrow("note"));
            data.add(new WeightEntry(id, date, weight, note));
        }
        cursor.close();
        adapter.notifyDataSetChanged();
        tvEmpty.setVisibility(data.isEmpty() ? TextView.VISIBLE : TextView.GONE);
    }

    private void clearInputs() {
        etDate.setText(""); etWeight.setText(""); etNote.setText("");
        etDate.requestFocus();
    }

    private void showEditDialog(int pos) {
        WeightEntry entry = data.get(pos);
        final EditText input = new EditText(this);
        input.setHint("New weight (lb)");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(String.valueOf(entry.weight));

        new AlertDialog.Builder(this)
                .setTitle("Update Weight for " + entry.date)
                .setView(input)
                .setPositiveButton("Save", (d, which) -> {
                    try {
                        double newWeight = Double.parseDouble(input.getText().toString().trim());
                        dbHelper.updateWeight(entry.id, newWeight);
                        loadWeights();
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    interface RowActions { void onDelete(int pos); void onEdit(int pos); }

    static class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.VH> {
        private final List<WeightEntry> list; private final RowActions actions;
        WeightAdapter(List<WeightEntry> l, RowActions a){ list=l; actions=a; }

        static class VH extends RecyclerView.ViewHolder {
            TextView tvDate, tvWeight, tvNote; ImageButton btnEdit, btnDelete;
            VH(@NonNull android.view.View itemView) {
                super(itemView);
                tvDate = itemView.findViewById(R.id.tvDate);
                tvWeight = itemView.findViewById(R.id.tvWeight);
                tvNote = itemView.findViewById(R.id.tvNote);
                btnEdit = itemView.findViewById(R.id.btnEdit);
                btnDelete = itemView.findViewById(R.id.btnDelete);
            }
        }

        @NonNull @Override public VH onCreateViewHolder(@NonNull android.view.ViewGroup parent, int viewType) {
            android.view.View v = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_weight, parent, false);
            return new VH(v);
        }

        @Override public void onBindViewHolder(@NonNull VH h, int pos) {
            WeightEntry e = list.get(pos);
            h.tvDate.setText(e.date);
            h.tvWeight.setText("Weight: " + e.weight + " lb");
            h.tvNote.setText("Note: " + (TextUtils.isEmpty(e.note) ? "—" : e.note));
            h.btnDelete.setOnClickListener(v -> actions.onDelete(h.getAdapterPosition()));
            h.btnEdit.setOnClickListener(v -> actions.onEdit(h.getAdapterPosition()));
        }
        @Override public int getItemCount() { return list.size(); }
    }
}