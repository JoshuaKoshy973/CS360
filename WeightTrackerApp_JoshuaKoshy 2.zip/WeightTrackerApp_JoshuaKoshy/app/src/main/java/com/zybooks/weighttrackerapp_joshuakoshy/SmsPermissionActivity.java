package com.zybooks.weighttrackerapp_joshuakoshy;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private LinearLayout groupGranted, groupDenied;
    private TextView tvSendStatus;
    private EditText etPhoneNumber;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), this::renderState);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        groupGranted = findViewById(R.id.groupGranted);
        groupDenied  = findViewById(R.id.groupDenied);
        Button btnRequest  = findViewById(R.id.btnRequest);
        Button btnSendTest = findViewById(R.id.btnSendTest);
        tvSendStatus = findViewById(R.id.tvSendStatus);

        // Add a phone number input inside your layout for real sending
        etPhoneNumber = new EditText(this);
        etPhoneNumber.setHint("Enter phone number");
        groupGranted.addView(etPhoneNumber, 0);

        btnRequest.setOnClickListener(v -> checkOrRequest());
        btnSendTest.setOnClickListener(v -> {
            String number = etPhoneNumber.getText().toString().trim();
            if (number.isEmpty()) {
                Toast.makeText(this, "Enter phone number", Toast.LENGTH_SHORT).show();
                return;
            }
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(number, null, "Test SMS from WeightTrackerApp", null, null);
            tvSendStatus.setText("Test SMS sent.");
        });

        renderState(isGranted());
    }

    private boolean isGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void checkOrRequest() {
        if (isGranted()) {
            renderState(true);
        } else {
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void renderState(boolean granted) {
        groupGranted.setVisibility(granted ? View.VISIBLE : View.GONE);
        groupDenied.setVisibility(granted ? View.GONE : View.VISIBLE);
        tvSendStatus.setText("");
    }
}
